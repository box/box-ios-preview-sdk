//
//  Constants.swift
//  iOSExampleApp
//
//  Created by Abel Osorio on 6/7/19.
//  Copyright © 2019 Box. All rights reserved.
//

import Foundation

enum Constants {
//        #error("Insert the client ID of your app")
        static let clientId = "qaemkg45bx8fn0qcwqlslfv4d3kh5tak"

//        #error("Insert the client ID of your app")
        static let clientSecret = "q7B4bQBQcv3xs9THfpQFBNKHYVzbbZnt"
}
