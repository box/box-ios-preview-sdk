//
//  BOXPreviewView.h
//  BOXPreviewSDK
//
//  Copyright (c) 2015 Box. All rights reserved.
//

@interface BOXPreviewView : UIView

- (instancetype)initWithPreviewClient:(BOXPreviewClient *)previewClient;

@property (nonatomic, readwrite, assign) BOOL displayFileName;
@property (nonatomic, readwrite, strong) BOXFile *file;
@property (nonatomic, readwrite, strong) NSURL *sharedLink;

@end
