//
//  BOXFilePreviewController.h
//  BOXPreviewSDK
//
//  Copyright (c) 2015 Box. All rights reserved.
//

@protocol BOXFilePreviewControllerDelegate;

@interface BOXFilePreviewController : UIViewController

@property (nonatomic, readwrite, assign) BOOL shouldHideBars;
@property (nonatomic, readwrite, assign) BOOL shouldHideStatusBar;
@property (nonatomic, readonly, strong) BOXPreviewClient *client;
@property (nonatomic, readwrite, assign) id<BOXFilePreviewControllerDelegate> delegate;

- (instancetype)initWithPreviewClient:(BOXPreviewClient *)previewClient
                                 item:(BOXItem *)item;

- (instancetype)initWithPreviewClient:(BOXPreviewClient *)previewClient
                                 item:(BOXItem *)item
                              inItems:(NSArray *)items;

- (instancetype)initWithContentClient:(BOXContentClient *)contentClient
                                 item:(BOXItem *)item;

- (instancetype)initWithContentClient:(BOXContentClient *)contentClient
                                 item:(BOXItem *)item
                              inItems:(NSArray *)items;

@end

@protocol BOXFilePreviewControllerDelegate<NSObject>

@optional

- (NSArray *)boxFilePreviewController:(BOXFilePreviewController *)controller
    willChangeToLeftBarButtonItems:(NSArray *)items;

- (NSArray *)boxFilePreviewController:(BOXFilePreviewController *)controller
   willChangeToRightBarButtonItems:(NSArray *)items;

@end