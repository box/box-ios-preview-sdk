//
//  Constants.swift
//  iOSExampleApp
//
//  Created by Abel Osorio on 6/7/19.
//  Copyright © 2019 Box. All rights reserved.
//

import Foundation

enum Constants {
        #error("Insert the client ID of your app")
        static let clientId = ""

        #error("Insert the client ID of your app")
        static let clientSecret = ""
}
