//
//  BOXPreviewClient.h
//  BoxPreviewSDK
//
//  Copyright (c) 2015 Box. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BoxContentSDK/BoxContentSDK.h>

/**
 *  Convenience enum for the max size for the cache.
 */
typedef NS_ENUM(NSUInteger, BOXPreviewClientCacheSize) {
    BOXPreviewClientCacheSize256MB = 256 * 1024 * 1024,
    BOXPreviewClientCacheSize512MB = 512 * 1024 * 1024,
    BOXPreviewClientCacheSize1GB = 1024 * 1024 * 1024,
    BOXPreviewClientCacheSizeDefault = BOXPreviewClientCacheSize1GB
};

/**
 *  Convenience enum for the max age for files in the cache.
 */
typedef NS_ENUM(NSUInteger, BOXPreviewClientCacheAge) {
    BOXPreviewClientCacheAge7Days = 7 * 24 * 60 * 60,
    BOXPreviewClientCacheAge30Days = 30 * 24 * 60 * 60,
    BOXPreviewClientCacheAge90Days = 90 * 24 * 60 * 60,
    BOXPreviewClientCacheAgeDefault = BOXPreviewClientCacheAge90Days
};

#pragma mark Notifications
/**
 *  Notification when the cache exceeds the maximum size and removal of oldest files is triggered.
 */
extern NSString *const BOXPreviewCacheDidExceedMaxSizeNotification;
/**
 *  Notification when files are removed from the cache. Includes an array of deleted file IDs in userInfo.
 */
extern NSString *const BOXPreviewCacheDidRemoveFilesNotification;

#pragma mark Keys
/**
 *  Key for BOXPreviewCacheDidRemoveFilesNotification's userInfo dictionary.
 *  Value is an NSArray of file IDs that were removed from the cache.
 */
extern NSString *const BOXPreviewCacheRemovedFileIDsKey;

@protocol BOXPreviewClientDelegate;

@interface BOXPreviewClient : NSObject

/**
 *  Content client used to make requests.
 */
@property (nonatomic, readonly, strong) BOXContentClient *client;

/**
 *  Delegate for cache control.
 */
@property (nonatomic, readwrite, assign) id <BOXPreviewClientDelegate> delegate;

/**
 *  Creates and instantiates a BOXPreviewClient.
 *
 *  @param contentClient The BOXContentClient for the current session.
 *
 *  @return A new BOXPreviewClient.
 */
- (instancetype)initWithContentClient:(BOXContentClient *)contentClient;

/**
 *  Creates and instantiates a BOXPreviewClient.
 *
 *  @param contentClient    The BOXContentClient for the current session.
 *  @param cacheDirectory   The base directory for the cache.
 *
 *  @return A new BOXPreviewClient.
 */
- (instancetype)initWithContentClient:(BOXContentClient *)contentClient
                       cacheDirectory:(NSURL *)cacheDirectory;

/**
 *  Downloads and caches a BOXFile. If the file is already cached, the content data will be immediately surfaced in the completion block.
 *
 *  @param fileID          The ID of the BOXFile
 *  @param progressBlock   The block to be executed while a download request is ongoing before completion.
 *  @param completionBlock The block to be executed either when finished downloading the file or successfully fetched from the cache.
 *
 *  @return A BOXRequest to download the BOXFile if it is not cached; otherwise, nil. Can be canceled.
 */
- (BOXRequest *)cacheFileWithID:(NSString *)fileID
                       progress:(BOXProgressBlock)progressBlock
                     completion:(BOXFileBlock)completionBlock;

/**
 *  Deletes the cache for file with a given file ID. 
 *  The method will delete the content of the file only when no other files share the same content with it.
 *  
 *  @param fileID The ID of the BOXFile
 */
- (void)removeCacheForFileWithID:(NSString *)fileID;

/**
 *  Checks if a BOXFile is cached or not.
 *
 *  @param fileID The ID of the BOXFile to inspect in the filesystem cache for.
 *
 *  @return Returns YES if BOXFile is cached; otherwise, NO.
 */
- (BOOL)isFileWithIDCached:(NSString *)fileID;

/**
 *  Sets the directory for the location of the cache. A new directory will be created inside this for the cache.
 *
 *  By default, we set up a cache directory in their Sandbox.
 *  The developer can override, which may be necessary if they need to put it into a shared container for extensions.
 *
 *  @param cacheDirectory The directory in which the cache will be stored.
 */
- (void)setCacheDirectory:(NSURL *)cacheDirectory;

/**
 *  Sets the maximum size for the cache. 
 *  Default is 1 GB.
 *
 *  @param cacheSize The max size of the cache.
 */
- (void)setMaxCacheSize:(BOXPreviewClientCacheSize)cacheSize;

/**
 *  Sets the maximum age for items in the cache before they are removed, based on "last used". 
 *  Default is 90 days.
 *
 *  @param cacheAge The max age for items in the cache.
 */
- (void)setMaxCacheAge:(BOXPreviewClientCacheAge)cacheAge;

/**
 *  Sets whether or not the cache is allowed to exist if the user does not have a passcode enabled to support encryption.
 *  Default is NO.
 *
 *  @param cacheAllowedWithoutEncryption Whether or not the cache can exist without encryption.
 */
- (void)setCacheAllowedWithoutEncryption:(BOOL)cacheAllowedWithoutEncryption;

/**
 *  Clears files from the cache until below the max cache size.
 */
- (void)purgeCache;

/**
 *  Resets the cache by deleting all the contents.
 */
- (void)resetCache;

/**
 *  Downloads and caches a file's preview image. 
 *  If the file is already cached, the content data will be immediately surfaced in the completion block.
 *
 *  @param file            The BOXFile model.
 *  @param completionBlock The block to be executed either when finished downloading the file or successfully fetched from the cache.
 *
 *  @return A BOXRequest to download the BOXFile's preview image if it is not cached; otherwise, nil. Can be canceled.
 */
- (BOXRequest *)retrievePreviewImageForFile:(BOXFile *)file
                                 completion:(BOXImageBlock)completionBlock;

/**
 *  Retrieve underlying file's info for a shared link. If the shared link is not for a file, we return nil in completion.
 *
 *  @param sharedLink      The file's shared link.
 *  @param completionBlock The block to be executed after file info is retrieved.
 *
 *  @return A BOXRequest to retrieve the file for a shared link. Can be canceled.
 */
- (BOXRequest *)retrieveFileForSharedLink:(NSURL *)sharedLink
                               completion:(BOXFileBlock)completionBlock;

/**
 *  Retrieves the file URL for an image or video file thumbnail asset in the cache.
 *
 *  @param file The file to return a thumbnail file URL for.
 *
 *  @return file URL for the file's thumbnail entry in the cache.
 */
- (NSURL *)fileURLForThumbnailCacheEntryForFile:(BOXFile *)file;

/**
 *  Retrieves the file URL for a file's preview content in the cache.
 *
 *  @param file The file to return a preview content file URL for.
 *
 *  @return file URL for the file's content entry in the cache.
 */
- (NSURL *)fileURLForContentPreviewCacheEntryForFile:(BOXFile *)file;

@end

@protocol BOXPreviewClientDelegate <NSObject>

@optional

/**
 *  Allows developers to prevent a particular file from being deleted from the cache by returning NO.
 *
 *  @param previewClient The preview client that is going to be removing the file.
 *  @param fileID        The ID of the file that is going to be removed.
 *
 *  @return whether the preview client is allowed to delete the file from the cache.
 */
- (BOOL)shouldPreviewClient:(BOXPreviewClient *)previewClient deleteCacheForFileWithID:(NSString *)fileID;

@end