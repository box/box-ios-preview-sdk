//
//  BOXFilePreviewController.h
//  BoxPreviewSDK
//
//  Copyright (c) 2015 Box. All rights reserved.
//

@protocol BOXFilePreviewControllerDelegate;

@interface BOXFilePreviewController : UIViewController

/**
 *  Property for whether the navigation bar and toolbar should be hidden on interaction.
 *  Default is YES.
 */
@property (nonatomic, readwrite, assign) BOOL shouldHideBars;

/**
 *  Property for whether the status bar should be hidden on interaction.
 *  Default is YES.
 */
@property (nonatomic, readwrite, assign) BOOL shouldHideStatusBar;

/**
 *  Preview client associated with this view controller.
 */
@property (nonatomic, readonly, strong) BOXPreviewClient *client;

/**
 *  Delegate for customizing the view controller's appearance.
 */
@property (nonatomic, readwrite, assign) id<BOXFilePreviewControllerDelegate> delegate;

/**
 *  Creates and instantiates a BOXFilePreviewController with a customized preview client.
 *
 *  @param previewClient The preview client to be associated with this view controller.
 *  @param file          The file whose preview should be shown.
 *
 *  @return A new BOXFilePreviewController.
 */
- (instancetype)initWithPreviewClient:(BOXPreviewClient *)previewClient
                                 file:(BOXFile *)file;

/**
 *  Creates and instantiates a BOXFilePreviewController with a customized preview client.
 *
 *  @param previewClient The preview client to be associated with this view controller.
 *  @param file          The file whose preview should be shown.
 *  @param items         An array of items containing the file and other related items to be viewed.
 *
 *  @return A new BOXFilePreviewController.
 */
- (instancetype)initWithPreviewClient:(BOXPreviewClient *)previewClient
                                 file:(BOXFile *)file
                              inItems:(NSArray *)items;

/**
 *  Creates and instantiates a BOXFilePreviewController with a default preview client.
 *
 *  @param contentClient The content client to use for creating a default preview client.
 *  @param file          The file whose preview should be shown.
 *
 *  @return A new BOXFilePreviewController.
 */
- (instancetype)initWithContentClient:(BOXContentClient *)contentClient
                                 file:(BOXFile *)file;

/**
 *  Creates and instantiates a BOXFilePreviewController with a default preview client.
 *
 *  @param contentClient The content client to use for creating a default preview client.
 *  @param file          The file whose preview should be shown.
 *  @param items         An array of items containing the file and other related items to be viewed.
 *
 *  @return A new BOXFilePreviewController.
 */
- (instancetype)initWithContentClient:(BOXContentClient *)contentClient
                                 file:(BOXFile *)file
                              inItems:(NSArray *)items;

@end

@protocol BOXFilePreviewControllerDelegate<NSObject>

@optional

/**
 *  Allows the developer to customize the left bar button items for the view controller.
 *
 *  @param controller The controller to customize.
 *  @param items      An array of bar button items to set as the left bar button items.
 *
 *  @return The items that will be set as the left bar button items for the view controller.
 */
- (NSArray *)boxFilePreviewController:(BOXFilePreviewController *)controller
       willChangeToLeftBarButtonItems:(NSArray *)items;

/**
 *  Allows the developer to customize the right bar button items for the view controller.
 *
 *  @param controller The controller to customize.
 *  @param items      An array of bar button items to set as the right bar button items.
 *
 *  @return The items that will be set as the right bar button items for the view controller.
 */
- (NSArray *)boxFilePreviewController:(BOXFilePreviewController *)controller
      willChangeToRightBarButtonItems:(NSArray *)items;

@end