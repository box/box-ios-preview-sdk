//
//  BOXPreviewClient.h
//  BOXPreviewSDK
//
//  Copyright (c) 2015 Box. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BoxContentSDK/BoxContentSDK.h>

typedef NS_ENUM(NSUInteger, BOXPreviewClientCacheSize) {
    BOXPreviewClientCacheSize256MB = 256 * 1024 * 1024,
    BOXPreviewClientCacheSize512MB = 512 * 1024 * 1024,
    BOXPreviewClientCacheSize1GB = 1024 * 1024 * 1024,
    BOXPreviewClientCacheSizeDefault = BOXPreviewClientCacheSize1GB
};

typedef NS_ENUM(NSUInteger, BOXPreviewClientCacheAge) {
    BOXPreviewClientCacheAge7Days = 7 * 24 * 60 * 60,
    BOXPreviewClientCacheAge30Days = 30 * 24 * 60 * 60,
    BOXPreviewClientCacheAge90Days = 90 * 24 * 60 * 60,
    BOXPreviewClientCacheAgeDefault = BOXPreviewClientCacheAge90Days
};

#pragma mark Notifications
extern NSString *const BOXPreviewCacheDidExceedMaxSizeNotification;
extern NSString *const BOXPreviewCacheDidRemoveFilesNotification;

#pragma mark Keys
extern NSString *const BOXPreviewCacheRemovedFileIDsKey;

@protocol BOXPreviewClientDelegate;

@interface BOXPreviewClient : NSObject

@property (nonatomic, readonly, strong) BOXContentClient *client;
@property (nonatomic, readwrite, assign) id <BOXPreviewClientDelegate> delegate;

/**
 *  Creates and instantiates a BOXPreviewClient.
 *
 *  @param contentClient The BOXContentClient for the current session.
 *
 *  @return A new BOXPreviewClient.
 */
- (instancetype)initWithContentClient:(BOXContentClient *)contentClient;

/**
 *  Creates and instantiates a BOXPreviewClient.
 *
 *  @param contentClient The BOXContentClient for the current session.
 *  @param cacheDirectory   The base directory for the cache.
 *
 *  @return A new BOXPreviewClient.
 */
- (instancetype)initWithContentClient:(BOXContentClient *)contentClient
                       cacheDirectory:(NSURL *)cacheDirectory;

/**
 *  Downloads and caches a BOXFile. If the file is already cached, the content data will be immediately surfaced in the completion block.
 *
 *  @param fileID          The ID of the BOXFile
 *  @param progressBlock   The block to be executed while a download request is ongoing before completion.
 *  @param completionBlock The block to be executed either when finished downloading the file or successfully fetched from the cache.
 *
 *  @return A BOXRequest to download the BOXFile if it is not cached; otherwise, nil. Can be canceled.
 */
- (BOXRequest *)cacheFileWithID:(NSString *)fileID
                       progress:(BOXProgressBlock)progressBlock
                     completion:(BOXFileBlock)completionBlock;

/**
 *  Deletes the cache for file with a given file ID. The method will delete the content of the file only when no other files share the same content with it.
 *  
 *  @param fileID The ID of the BOXFile
 */
- (void)removeCacheForFileWithID:(NSString *)fileID;

/**
 *  Checks the cache if a BOXFile is cached or not.
 *
 *  @param fileID The ID of the BOXFile to inspect in the filesystem cache for.
 *
 *  @return Returns YES if BOXFile is cached; otherwise, NO.
 */
- (BOOL)isFileWithIDCached:(NSString *)fileID;

/**
 * By default, we set up a cache directory in their Sandbox with a default name.
 * But the developer can override, which may be necessary if they need to put it into a shared container for extensions.
 */
- (void)setCacheDirectory:(NSURL *)cacheDirectory;

/*
 * We have a default max cache size (e.g. 200MB).
 * But the developer can override.
 */
- (void)setMaxCacheSize:(BOXPreviewClientCacheSize)cacheSize;

/**
 * We have a default max age for cache items (e.g. 7 days). Age is based on "last used".
 * But the developer can override.
 */
- (void)setMaxCacheAge:(BOXPreviewClientCacheAge)cacheAge;

/**
 * If user does not have passcode enabled to support encryption, then by default
 * we do not allow a cache.
 * Developer can override this.
 * http://stackoverflow.com/questions/21337563/programmatically-detect-whether-ios-passcode-is-enabled-or-not
 */
- (void)setCacheAllowedWithoutEncryption:(BOOL)cacheAllowedWithoutEncryption;

// Clear files from the cache until below the max cache size.
- (void)purgeCache;

/**
 *  Reset the cache by deleting all the contents.
 */
- (void)resetCache;

/**
 *  Downloads and caches a file's preview image. If the file is already cached, the content data will be immediately surfaced in the completion block.
 *
 *  @param file            The BOXFile model
 *  @param completionBlock The block to be executed either when finished downloading the file or successfully fetched from the cache.
 *
 *  @return A BOXRequest to download the BOXFile's preview image if it is not cached; otherwise, nil. Can be canceled.
 */
- (BOXRequest *)retrievePreviewImageForFile:(BOXFile *)file
                                 completion:(BOXImageBlock)completionBlock;

/**
 *  Retrieve underlying file's info for a shared link. If the shared link is not for a file, we return nil in completion.
 *
 *  @param sharedLink      The file's shared link.
 *  @param completionBlock The block to be executed after file info is retrieved.
 *
 *  @return A BOXRequest to retrieve the file for a shared link. Can be canceled.
 */
- (BOXRequest *)retrieveFileForSharedLink:(NSURL *)sharedLink
                               completion:(BOXFileBlock)completionBlock;

@end

@protocol BOXPreviewClientDelegate <NSObject>

@optional

// Optional. If implemented, allows developers to prevent the cache for a particular file from being deleted.
- (BOOL)shouldPreviewClient:(BOXPreviewClient *)previewClient deleteCacheForFileWithID:(NSString *)fileID;

@end