//
//  ViewController.swift
//  iOSSwiftExample
//
//  Created by Abel Osorio on 3/13/19.
//  Copyright © 2019 Box Inc. All rights reserved.
//

import BoxPreviewSDK
import BoxSDK
import UIKit

class ViewController: UITableViewController {

    var contentSDK: BoxSDK!
    var client: BoxClient!
    var previewSDK: BoxPreviewSDK?
    var folderItems: [FolderItem] = []
    private lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM dd,yyyy at HH:mm a"
        return formatter
    }()

    // MARK: - View life cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Preview"
        contentSDK = BoxSDK(clientId: Constants.clientId, clientSecret: Constants.clientSecret)
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Login", style: .plain, target: self, action: #selector(loginPressed))
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        tableView.tableFooterView = UIView()
        let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(getRootFolderItems), for: .valueChanged)
        tableView.refreshControl = refresh
    }

    // MARK: - Actions

    @objc func loginPressed() {
        getOAuthClient()
    }
    
    @objc func logoutPressed() {
        let alertController = UIAlertController(title: "Logout", message: "Are you sure you want to log out?", preferredStyle: .alert)
        
        let action1 = UIAlertAction(title: "Ok", style: .default) { [weak self] _ in
            guard let self = self else { return }
            self.logout()
        }
        
        let action2 = UIAlertAction(title: "Cancel", style: .cancel) { _ in }
        
        alertController.addAction(action1)
        alertController.addAction(action2)
        self.present(alertController, animated: true, completion: nil)
    }

    // MARK: - Table view data source

    override func numberOfSections(in _: UITableView) -> Int {
        return 1
    }

    override func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        return folderItems.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FileCell", for: indexPath)
        let item = folderItems[indexPath.row]
        if case let .file(file) = item.itemValue {
            cell.textLabel?.text = file.name
            cell.detailTextLabel?.text = String(format: "Date Modified %@", dateFormatter.string(from: file.modifiedAt ?? Date()))
            cell.accessoryType = .none
        }
        else if case let .folder(folder) = item.itemValue {
            cell.textLabel?.text = folder.name
            cell.detailTextLabel?.text = ""
            cell.accessoryType = .disclosureIndicator
            cell.imageView?.image = UIImage(named: "folderIcon")
        }

        return cell
    }

    override func tableView(_: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = folderItems[indexPath.row]
        if case let .file(file) = item.itemValue {
            showPreviewViewController(fileId: file.id)
        }
    }
}

// MARK: - Helpers

private extension ViewController {
    func getOAuthClient() {
        tableView.refreshControl?.beginRefreshing()
        contentSDK.getOAuth2Client(tokenStore: KeychainTokenStore()) { [weak self] result in
            switch result {
            case let .success(client):
                self?.client = client
                self?.previewSDK = BoxPreviewSDK(client: client)
                self?.getRootFolderItems()
            case let .failure(error):
                print("\(error)")
            }
        }
    }

    @objc func getRootFolderItems() {
        let iterator: PaginationIterator<FolderItem> = client.folders.getFolderItems(
            folderId: "0",
            usemarker: true,
            fields: ["modified_at", "name"]
        )

        iterator.nextItems { [weak self] result in
            switch result {
            case let .success(items):
                self?.folderItems = items.filter {
                    if case .file = $0.itemValue { return true }
                    return false
                }
            case let .failure(error):
                print("error: \(error)")
            }
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Log out", style: .plain, target: self, action: #selector(self.logoutPressed))
                self.tableView.refreshControl?.endRefreshing()
                self.tableView.reloadData()
            }
        }
    }

    func showPreviewViewController(fileId: String) {
        let previewController: PreviewViewController? = previewSDK?.openFile(fileId: fileId, delegate: self)

        guard let unwrappedPreviewController = previewController else {
            return
        }

        navigationController?.pushViewController(unwrappedPreviewController, animated: true)
    }
    
    func logout() {
        tableView.refreshControl?.beginRefreshing()
        client.destroy { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success:
                self.folderItems.removeAll()
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Login", style: .plain, target: self, action: #selector(self.loginPressed))
                    self.tableView.refreshControl?.endRefreshing()
                    self.tableView.reloadData()
                }
            case let .failure(error):
                print(error)
            }
        }
    }
}

extension ViewController: PreviewViewControllerDelegate {
    func previewViewControllerFailed(error: BoxPreviewError) {
        print("Error: \(error)")
    }
}
