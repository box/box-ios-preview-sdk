//
//  ExamplesTableViewController.swift
//  iOSExampleApp
//
//  Created by Abel Osorio on 6/7/19.
//  Copyright © 2019 Box. All rights reserved.
//

import UIKit

class ExamplesTableViewController: UITableViewController {

    private var examples = ["OAuth2.0 Authentication"]

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Box PreviewSDK Sample"
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        tableView.tableFooterView = UIView()
    }

    // MARK: - Table view data source

    override func numberOfSections(in _: UITableView) -> Int {
        return 1
    }

    override func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        return examples.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = examples[indexPath.row]
        return cell
    }

    override func tableView(_: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: examples[indexPath.row], sender: nil)
    }
}
